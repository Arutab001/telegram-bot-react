import React from 'react';
import Body from "./Body.js";
import CoinBox from "./CoinBox.js";
import NewsBox from "./NewsBox.js";


const Home = () => {

    return (
        <div>
            <Body />
        </div>
    );
};

export default Home;